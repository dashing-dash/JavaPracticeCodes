class Bucket {
    int low;
    int high;
    public Bucket() {
        low = -1;
        high = -1;
    }
}