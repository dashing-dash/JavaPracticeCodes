public class Spiral2{
    public ArrayList<Integer> spiralOrder(final List<ArrayList<Integer>> A) {
   ArrayList<Integer> result = new ArrayList<Integer>();
    }
    
}