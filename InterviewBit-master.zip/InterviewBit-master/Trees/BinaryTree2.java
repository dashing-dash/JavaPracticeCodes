/*
 * Given preorder and inorder traversal of a tree, construct the binary tree.

Note: You may assume that duplicates do not exist in the tree.
Example :

Input :
        Preorder : [1, 2, 3]
        Inorder  : [2, 1, 3]

Return :
            1
           / \
          2   3

 */
import java.util.*;
public class BinaryTree2{
    
    public static void main(String[] args){
    }
}