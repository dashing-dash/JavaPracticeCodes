/*
 * 
 */
public class KnightEfficient {
    public class Vertex {
        int x;
        int y;
        public Vertex(int x, int y){
            this.x = x;
            this.y = y;
        }        
    }
    public class Graph {
        Vertex[]  vertices = new Vertex[];
        private Bag<Vertex>[] adj;
        public Graph(int x1, int y1){
            
            
        }
        public void addEdge(Vertex v, Vertex w){
        }
        
        
    }
    
    
    public int knight(int N, int M, int x1, int y1, int x2, int y2) {
        
    }
    
    public static void main(String[] args){
    }
}