/*
 * 
 */
public class Rank2Efficient {
    public static int findRank(String A){
        
    }
    public static void main(String[] args) {
        
    }
}