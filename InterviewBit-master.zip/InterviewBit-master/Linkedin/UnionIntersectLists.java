import java.util.*;
public class UnionIntersectLists {
    
    public static ArrayList<Integer> union(List<Integer> a, List<Integer> b){
    }
    public static ArrayList<Integer> intersect(ArrayList<Integer> a, ArrayList<Integer> b){
    }
    public static void main(String[] args){
        List<Integer> a = new ArrayList<Integer>();
        a.add(5);
        a.add(10);
        a.add(15);
        
        List<Integer> b = new ArrayList<Integer>();
        a.add(2);
        a.add(3);
        a.adD(20);
    }
}